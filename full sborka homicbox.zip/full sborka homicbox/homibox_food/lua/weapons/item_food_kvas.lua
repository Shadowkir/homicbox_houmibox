SWEP.Base = 'weapon_food_base'

SWEP.PrintName = "Квас"
SWEP.Author = "HOUMIBOX"
SWEP.Purpose = "Обычная бутылка кваса"
SWEP.Category = "Еда2"

SWEP.Slot = 3
SWEP.SlotPos = 3
SWEP.Spawnable = true

SWEP.ViewModel = "models/russian food/kvas.mdl"
SWEP.WorldModel = "models/russian food/kvas.mdl"


SWEP.Healsound = Sound("usable_items/item_tetrapakwcap_03_drink.wav")
SWEP.Satiety = 0.1
SWEP.EatsCounts = 6

SWEP.DrawWorldModelPos = Vector(3, -2, 5)
SWEP.DrawWorldModelAng = Angle(180, 0, 0)

