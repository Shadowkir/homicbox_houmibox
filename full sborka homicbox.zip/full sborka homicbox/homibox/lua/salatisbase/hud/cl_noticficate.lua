--
local net_Recive = net.Receive
local net_ReadTable = net.ReadTable
local table_Insert = table.insert
local table_remove = table.remove
local draw_SimpleText = draw.SimpleText
local surface_DrawRect = surface.DrawRect
local surface_SetDrawColor = surface.SetDrawColor
local Notifications = {}
local Notic_Si_xd = {}

surface.CreateFont( "ConnectveChells", {
    font = "HudHintTextSmall", --  Use the font-name which is shown to you by your operating system Font Viewer, not the file name
    extended = true,
    size = 20,
    weight = 500,

} )

Notificate = Notificate or {}

Notificate.Create = function(str, time, color)
    local Send = {
        ["string"] = str,
        ["time"] = CurTime()+(time or 5),
        ["color"] = color
    }

    print(str)

    table_Insert(Notifications,Send)
end

Notic_Si = Notic_Si or {}

Notic_Si.Server = function(str, time, color, sound)
    local Send = {
        ["string"] = str,
        ["time"] = CurTime()+(time or 5),
        ["color"] = color,
        ["sound"] = sound
    }

    print(str)

    table_Insert(Notic_Si_xd, Send)

    for k, v in pairs(Notic_Si_xd) do
        v.sound = v.sound or "Friends/friend_online.wav"
        surface.PlaySound(v.sound)
    end
end

Notificate.Create("весь код спиздил шадоукир",10)
Notificate.Create("добро пожаловать на хоумибокс!",10)

-- Notic_Si.Server("Test".." Подключился на сервер", 5)

local function EaseLerp(fraction, from, to)
    return Lerp(math.ease.OutCubic(fraction), from, to)
end

net_Recive("notificate_created",function()
    local Table = net_ReadTable()

    table_Insert(Notifications,Table)
end)

net_Recive("notificate_created2",function()
    local Table = net_ReadTable()



    table_Insert(Notic_Si_xd,Table)


    for k, v in pairs(Notic_Si_xd) do
        v.sound = v.sound or "Friends/friend_online.wav"
        surface.PlaySound(v.sound)
    end
     
end)

-- Notic_Si.Server("name".." - заходит на сервер", 5, Color(55,255,95))
-- Notic_Si.Server("name".." - возродился", 5, Color(55,255,166))
Notic_Si.Server("Player(id):Name()" .. " - отключился от сервера ( ".. "reason" .. " )", 5, Color(255,166,166))

hook.Add("HUDPaint", "SIB_Notificate", function()
    for k,v in pairs(Notifications) do
        v.txtSize = surface.GetTextSize(v.string)
        v.startTime = v.startTime or v.time-CurTime()

        v.anim = Lerp(5*FrameTime(), v.anim or 0, math.Clamp(v.time - CurTime(),0,1))

        v.posX = EaseLerp(v.anim, ScrW()+(v.txtSize*2.2), ScrW()-25)
        v.posY = Lerp(5*FrameTime(),v.posY or (ScrH()-(k*45))-40,(ScrH()-(k*45)-40))
        draw_SimpleText( v.string, "HomigradFontBig", v.posX, v.posY, v.color, TEXT_ALIGN_RIGHT )
        draw_SimpleText( string.Right(string.ToMinutesSecondsMilliseconds(v.time - CurTime()),5), "DermaDefault", v.posX, v.posY+22, Color(255,255,255), TEXT_ALIGN_RIGHT )
        if v.time+1 < CurTime() then table_remove(Notifications,k) end
    end

    for k, v in pairs(Notic_Si_xd) do
        v.txtSize = surface.GetTextSize(v.string)
        v.startTime = v.startTime or v.time-CurTime()

        v.anim = Lerp(5*FrameTime(), v.anim or 0, math.Clamp(v.time - CurTime(),0,1))

        v.posX = EaseLerp(v.anim, ScrW()+(v.txtSize*2.2), ScrW()-25)
        v.posY = Lerp(5*FrameTime(),v.posY or (0+(k*15)),(0+(k*25)))

        draw_SimpleText( v.string, "ConnectveChells", v.posX+1, v.posY+2, color_black, 2 )
        draw_SimpleText( v.string, "ConnectveChells", v.posX, v.posY, v.color, 2 )

        -- draw_SimpleText( string.Right(string.ToMinutesSecondsMilliseconds(v.time - CurTime()),5), "DermaDefault", v.posX, v.posY+22, Color(255,255,255), TEXT_ALIGN_RIGHT )
        if v.time+1 < CurTime() then table_remove(Notic_Si_xd, k) end
    end
end)


gameevent.Listen( "player_connect_client" )
hook.Add( "player_connect_client", "player_connect_client_example", function( data )
    local name = data.name          // Same as Player:Nick()
    local steamid = data.networkid  // Same as Player:SteamID()
    local id = data.userid          // Same as Player:UserID()
    local bot = data.bot            // Same as Player:IsBot()
    local index = data.index        // Same as Entity:EntIndex() minus one
        print(name.." - заходит на сервер")
    Notic_Si.Server(name.." - заходит на сервер", 5, Color(55,255,95))
    surface.PlaySound("Friends/friend_online.wav")
    
end)

hook.Add( "ChatText", "hide_joinleave", function( index, name, text, type )
    if ( type == "joinleave" ) then
        return true
    end
end )