SWEP.Base = 'salat_base' -- base



SWEP.PrintName 				= "HK416"

SWEP.Author 				= "Heckler & Koch"

SWEP.Instructions			= "The German rifle adapted to the American modular AR-15 system, created by Heckler & Koch."

SWEP.Category 				= "SIB Rifles"



SWEP.Spawnable 				= true

SWEP.AdminOnly 				= false



------------------------------------------



SWEP.Primary.ClipSize		= 30

SWEP.Primary.DefaultClip	= 30

SWEP.Primary.Automatic		= true

SWEP.Primary.Ammo			= "5.56x45 mm"

SWEP.Primary.Cone = 0

SWEP.Primary.Damage = 35

SWEP.Primary.Spread = 0

SWEP.Primary.Sound = "weapons/m4a4/fire01.wav"

SWEP.Primary.FarSound = "weapons/m4a4/distant.wav"

SWEP.Primary.Force = 20

SWEP.ReloadTime = 2.5

SWEP.ShootWait = 0.085

SWEP.ReloadSounds = {

    [0.1] = {"weapons/m4a4/clipout.wav"},

    [1.3] = {"weapons/m4a4/clipin.wav"},

    [2] = {"weapons/m4a4/cliphit.wav"},

}

SWEP.TwoHands = true

SWEP.Shell = "EjectBrass_556"

SWEP.ShellRotate = true 



SWEP.Secondary.ClipSize		= -1

SWEP.Secondary.DefaultClip	= -1

SWEP.Secondary.Automatic	= false

SWEP.Secondary.Ammo			= "none"



------------------------------------------



SWEP.Weight					= 5

SWEP.AutoSwitchTo			= false

SWEP.AutoSwitchFrom			= false



SWEP.HoldType = "ar2"



------------------------------------------



SWEP.Slot					= 2

SWEP.SlotPos				= 0

SWEP.DrawAmmo				= true

SWEP.DrawCrosshair			= false



SWEP.ViewModel				= "models/pwb/weapons/w_hk416.mdl"

SWEP.WorldModel				= "models/pwb/weapons/w_hk416.mdl"



SWEP.addAng = Angle(-0.3,0.4) -- Barrel pos adjust

SWEP.addPos = Vector(0,0,0) -- Barrel ang adjust

SWEP.SightPos = Vector(-10,0.96,5.4) -- Sight pos

SWEP.SightAng = Angle(-10,0,0) -- Sight ang



SWEP.Mobility = 1.3

