SWEP.Base = 'salat_base' -- base

SWEP.PrintName              = "HK23E"
SWEP.Author                 = "Heckler & Koch"
SWEP.Instructions           = "The HK23E is a belt-fed, light machine gun that can hold 100 rounds of 5.56 NATO per belt container."
SWEP.Category               = "SIB Machine Gun"

SWEP.Spawnable              = true
SWEP.AdminOnly              = false
if CLIENT then
	SWEP.WepSelectIcon = Material("pwb/sprites/hk23e.vmt")
	SWEP.IconOverride = "pwb/sprites/hk23e.vtf"
	SWEP.BounceWeaponIcon = false
end

------------------------------------------

SWEP.Primary.ClipSize       = 100
SWEP.Primary.DefaultClip    = 100
SWEP.Primary.Automatic      = true
SWEP.Primary.Ammo           = "5.56x45 mm"
SWEP.Primary.Cone = 0
SWEP.Primary.Damage = 45
SWEP.Primary.Spread = 0
SWEP.Primary.Sound = "pwb/weapons/hk23e/shoot.wav"
SWEP.Primary.FarSound = "weapons/g3sg1/distant01.wav"
SWEP.Primary.Force = 32
SWEP.ReloadTime = 4.2
SWEP.ShootWait = 0.09
SWEP.ReloadSounds = {
    [0.3] = {"pwb/weapons/hk23e/magout.wav"},

    [1.2] = {"pwb/weapons/hk23e/magin.wav"},
    
    [1.7] = {"pwb/weapons/hk23e/chain.wav"},
    
    [2.8] = {"pwb/weapons/hk23e/boltdown.wav"},
    
    [3.5] = {"pwb/weapons/hk23e/boltpull.wav"},
    
}
SWEP.TwoHands = true
SWEP.Shell = "EjectBrass_556"

SWEP.Secondary.ClipSize     = -1
SWEP.Secondary.DefaultClip  = -1
SWEP.Secondary.Automatic    = false
SWEP.Secondary.Ammo         = "none"

------------------------------------------

SWEP.Weight                 = 8
SWEP.AutoSwitchTo           = false
SWEP.AutoSwitchFrom         = false

SWEP.HoldType = "smg"

------------------------------------------

SWEP.Slot                   = 2
SWEP.SlotPos                = 0
SWEP.DrawAmmo               = true
SWEP.DrawCrosshair          = false

SWEP.ViewModel              = "models/pwb/weapons/w_hk23e.mdl"
SWEP.WorldModel             = "models/pwb/weapons/w_hk23e.mdl"

SWEP.addAng = Angle(-2,0,0) -- Barrel pos adjust

SWEP.addPos = Vector(0,0,0) -- Barrel ang adjust

SWEP.SightPos = Vector(-9,0.85,5.95) -- Sight pos

SWEP.SightAng = Angle(-10,0,0) -- Sight ang



SWEP.Mobility = 1