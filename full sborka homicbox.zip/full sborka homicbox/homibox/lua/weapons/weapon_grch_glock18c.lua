SWEP.Base = 'salat_base' -- base



SWEP.PrintName 				= "Glock 18c"

SWEP.Author 				= "Glock Ges.m.b.H."

SWEP.Instructions			= "The Austrian automatic pistol manufactured by Glock GmbH with a 9x19mm Parabellum caliber. It is intended for arming special forces of the army and police."

SWEP.Category 				= "SIB Pistols"



SWEP.Spawnable 				= true

SWEP.AdminOnly 				= false



------------------------------------------



SWEP.Primary.ClipSize		= 33

SWEP.Primary.DefaultClip	= 33

SWEP.Primary.Automatic		= true

SWEP.Primary.Ammo			= "9х19 mm Parabellum"

SWEP.Primary.Cone = 0

SWEP.Primary.Damage = 20

SWEP.Primary.Spread = 0

SWEP.Primary.Sound = "sounds_zcity/glock18c/close.wav"

SWEP.Primary.FarSound = "sounds_zcity/glock18c/dist.wav"

SWEP.Primary.Force = 20

SWEP.ReloadTime = 2

SWEP.ShootWait = 0.05

SWEP.ReloadSounds = {

    [0.1] = {"weapons/glock18/clipout.wav"},

    [1] = {"weapons/glock18/clipin.wav"},

    [1.4] = {"weapons/glock18/slideback.wav"},

    [1.6] = {"weapons/glock18/slideforward.wav"},

}



------------------------------------------



SWEP.Weight					= 5

SWEP.AutoSwitchTo			= false

SWEP.AutoSwitchFrom			= false



SWEP.HoldType = "revolver"



------------------------------------------



SWEP.Slot					= 1

SWEP.SlotPos				= 2

SWEP.DrawAmmo				= true

SWEP.DrawCrosshair			= false



SWEP.ViewModel				= "models/homicbox_weapons/w_pist_glock18_extended.mdl"

SWEP.WorldModel				= "models/homicbox_weapons/w_pist_glock18_extended.mdl"



SWEP.addAng = Angle(0.65,-0.05,0) -- Barrel ang adjust

SWEP.addPos = Vector(0,0,0) -- Barrel pos adjust

SWEP.SightPos = Vector(-14,1.54,3.7) -- Sight pos

SWEP.SightAng = Angle(0,8,0) -- Sight ang

