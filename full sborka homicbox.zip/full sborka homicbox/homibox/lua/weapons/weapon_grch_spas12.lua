SWEP.Base = 'salat_base' -- base

SWEP.PrintName 				= "Franchi SPAS-12"
SWEP.Author 				= "Luigi Franchi S.p.A."
SWEP.Instructions			= "The Italian semi-automatic and pump-action shotgun developed by Franchi in the late 1970s. The weapon was intended for the military, law enforcement agencies and special forces, combining the capabilities of self-loading and manual reloading."
SWEP.Category 				= "SIB Shotgun"

SWEP.Spawnable 				= true
SWEP.AdminOnly 				= false
if CLIENT then
	SWEP.WepSelectIcon = Material("pwb/sprites/spas_12.vmt")
	SWEP.IconOverride = "pwb/sprites/spas_12.vtf"
	SWEP.BounceWeaponIcon = false
end

------------------------------------------

SWEP.Primary.ClipSize		= 8
SWEP.Primary.DefaultClip	= 8
SWEP.Primary.Automatic		= false
SWEP.Primary.Ammo			= "12/70 gauge"
SWEP.Primary.Cone = 0.012
SWEP.Primary.Damage = 35
SWEP.Primary.Spread = 0
SWEP.Primary.Sound = "sounds_zcity/spas12/close.wav"
SWEP.Primary.FarSound = "sounds_zcity/spas12/dist.wav"
SWEP.Primary.Force = 90
SWEP.ReloadTime = 5
SWEP.ShootWait = 0.15
SWEP.NumBullet = 12
SWEP.ReloadSounds = {
    [0.3] = {"weapons/nova/insertshell01.wav"},
    [0.8] = {"weapons/nova/insertshell02.wav"},
    [1.3] = {"weapons/nova/insertshell03.wav"},
    [1.8] = {"weapons/nova/insertshell02.wav"},
    [2.3] = {"weapons/nova/insertshell01.wav"},
    [2.8] = {"weapons/nova/insertshell03.wav"},
    [3.3] = {"weapons/nova/insertshell02.wav"},
    [3.8] = {"weapons/nova/insertshell04.wav"},
    [4.3] = {"weapons/sawedoff/pump.wav"},
}
SWEP.TwoHands = true
SWEP.Shell = "EjectBrass_12Gauge"

SWEP.Secondary.ClipSize		= -1
SWEP.Secondary.DefaultClip	= -1
SWEP.Secondary.Automatic	= false
SWEP.Secondary.Ammo			= "none"

------------------------------------------

SWEP.Weight					= 5
SWEP.AutoSwitchTo			= false
SWEP.AutoSwitchFrom			= false

SWEP.HoldType = "ar2"

------------------------------------------

SWEP.Slot					= 2
SWEP.SlotPos				= 0
SWEP.DrawAmmo				= true
SWEP.DrawCrosshair			= false

SWEP.ViewModel				= "models/pwb/weapons/w_spas_12.mdl"
SWEP.WorldModel				= "models/pwb/weapons/w_spas_12.mdl"

SWEP.addAng = Angle(0,0,0) -- Barrel pos adjust
SWEP.addPos = Vector(0,0,0) -- Barrel ang adjust
SWEP.SightPos = Vector(-9,0.84,2.5) -- Sight pos
SWEP.SightAng = Angle(-8,0,0) -- Sight ang


SWEP.Mobility = 1.5