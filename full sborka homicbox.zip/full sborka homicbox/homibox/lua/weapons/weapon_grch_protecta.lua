SWEP.Base = 'salat_base' -- base

SWEP.PrintName 				= "Protecta"
SWEP.Author 				= "Reutech Defense Industries"
SWEP.Instructions			= "A 12-gauge (about 18.5 mm) smoothbore combat rifle, built according to a revolver pattern."
SWEP.Category 				= "SIB Shotgun"

SWEP.Spawnable 				= true
SWEP.AdminOnly 				= false
if CLIENT then
	SWEP.WepSelectIcon = Material("pwb/sprites/protecta.vmt")
	SWEP.IconOverride = "pwb/sprites/protecta.vtf"
	SWEP.BounceWeaponIcon = false
end

------------------------------------------

SWEP.Primary.ClipSize		= 12
SWEP.Primary.DefaultClip	= 12
SWEP.Primary.Automatic		= true
SWEP.Primary.Ammo			= "12/70 gauge"
SWEP.Primary.Cone = 0.017
SWEP.Primary.Damage = 37
SWEP.Primary.Spread = 0
SWEP.Primary.Sound = "pwb/weapons/protecta/shoot.wav"
SWEP.Primary.FarSound = "sounds_zcity/spas12/dist.wav"
SWEP.Primary.Force = 60
SWEP.ReloadTime = 10.5
SWEP.ShootWait = 0.23
SWEP.NumBullet = 12
SWEP.ReloadSounds = {
    [0.3] = {"pwb/weapons/protecta/pump.wav"},
    [1.0] = {"pwb/weapons/protecta/insert.wav"},
    [1.4] = {"pwb/weapons/rpk/boltpull.wav"},
    [1.8] = {"pwb/weapons/protecta/insert.wav"},
    [2.2] = {"pwb/weapons/rpk/boltpull.wav"},
    [2.6] = {"pwb/weapons/protecta/insert.wav"},
    [3] = {"pwb/weapons/rpk/boltpull.wav"},
    [3.4] = {"pwb/weapons/protecta/insert.wav"},
    [3.8] = {"pwb/weapons/rpk/boltpull.wav"},
    [4.2] = {"pwb/weapons/protecta/insert.wav"},
    [4.6] = {"pwb/weapons/rpk/boltpull.wav"},
    [5] = {"pwb/weapons/protecta/insert.wav"},
    [5.4] = {"pwb/weapons/rpk/boltpull.wav"},
    [5.8] = {"pwb/weapons/protecta/insert.wav"},
    [6.2] = {"pwb/weapons/rpk/boltpull.wav"},
    [6.6] = {"pwb/weapons/protecta/insert.wav"},
    [7] = {"pwb/weapons/rpk/boltpull.wav"},
    [7.4] = {"pwb/weapons/protecta/insert.wav"},
    [7.8] = {"pwb/weapons/rpk/boltpull.wav"},
    [8.2] = {"pwb/weapons/protecta/insert.wav"},
    [8.6] = {"pwb/weapons/rpk/boltpull.wav"},
    [9] = {"pwb/weapons/protecta/insert.wav"},
    [9.4] = {"pwb/weapons/rpk/boltpull.wav"},
    [9.8] = {"pwb/weapons/protecta/insert.wav"},
}
SWEP.TwoHands = true
SWEP.Shell = "EjectBrass_12Gauge"

SWEP.Secondary.ClipSize		= -1
SWEP.Secondary.DefaultClip	= -1
SWEP.Secondary.Automatic	= false
SWEP.Secondary.Ammo			= "none"

------------------------------------------

SWEP.Weight					= 5
SWEP.AutoSwitchTo			= false
SWEP.AutoSwitchFrom			= false

SWEP.HoldType = "smg"

------------------------------------------

SWEP.Slot					= 2
SWEP.SlotPos				= 0
SWEP.DrawAmmo				= true
SWEP.DrawCrosshair			= false

SWEP.ViewModel				= "models/pwb/weapons/w_protecta.mdl"
SWEP.WorldModel				= "models/pwb/weapons/w_protecta.mdl"

SWEP.addAng = Angle(0,0,0) -- Barrel pos adjust
SWEP.addPos = Vector(0,0,0) -- Barrel ang adjust
SWEP.SightPos = Vector(-9,0.6,3.47) -- Sight pos
SWEP.SightAng = Angle(-8,0,0) -- Sight ang


SWEP.Mobility = 1.5