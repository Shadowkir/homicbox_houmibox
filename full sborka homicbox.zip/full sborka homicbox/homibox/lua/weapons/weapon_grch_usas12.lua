SWEP.Base = 'salat_base' -- base

SWEP.PrintName 				= "Daewoo USAS-12"
SWEP.Author 				= "Gilbert Equipment Co Daewoo Precision Industries RAMO Defence"
SWEP.Instructions			= "An automatic shotgun developed by John Trevor in the late 1980s based on the ideas of another American designer Maxwell Atchisson, who created the Atchisson Assault Shotgun."
SWEP.Category 				= "SIB Shotgun"

SWEP.Spawnable 				= true
SWEP.AdminOnly 				= false

------------------------------------------

SWEP.Primary.ClipSize		= 10
SWEP.Primary.DefaultClip	= 10
SWEP.Primary.Automatic		= true
SWEP.Primary.Ammo			= "12/70 gauge"
SWEP.Primary.Cone = 0.020
SWEP.Primary.Damage = 30
SWEP.Primary.Spread = 0
SWEP.Primary.Sound = "zcitysnd/sound/weapons/toz_shotgun/toz_fp.wav"
SWEP.Primary.FarSound = "zcitysnd/sound/weapons/toz_shotgun/toz_dist.wav"
SWEP.Primary.Force = 63
SWEP.ReloadTime = 3
SWEP.ShootWait = 0.2
SWEP.NumBullet = 12
SWEP.ReloadSounds = {
    [0.1] = {"pwb/weapons/sr25/clipout.wav"},
    [1.3] = {"pwb/weapons/sr25/clipin.wav"},
    [1.8] = {"pwb/weapons/sr25/cliptap.wav"},
    [2.5] = {"pwb/weapons/sr25/boltrelease.wav"}
}
SWEP.TwoHands = true
SWEP.Shell = "EjectBrass_12Gauge"

SWEP.Secondary.ClipSize		= -1
SWEP.Secondary.DefaultClip	= -1
SWEP.Secondary.Automatic	= false
SWEP.Secondary.Ammo			= "none"

------------------------------------------

SWEP.Weight					= 5
SWEP.AutoSwitchTo			= false
SWEP.AutoSwitchFrom			= false

SWEP.HoldType = "ar2"

------------------------------------------

SWEP.Slot					= 2
SWEP.SlotPos				= 0
SWEP.DrawAmmo				= true
SWEP.DrawCrosshair			= false

SWEP.ViewModel				= "models/weapons/w_shot_u12.mdl"
SWEP.WorldModel				= "models/weapons/w_shot_u12.mdl"

SWEP.addAng = Angle(-1.3,0,0) -- Barrel pos adjust
SWEP.addPos = Vector(0,0,0) -- Barrel ang adjust
SWEP.SightPos = Vector(-9,0.122,7.15) -- Sight pos
SWEP.SightAng = Angle(-8,0,0) -- Sight ang


SWEP.Mobility = 1.5