

SWEP.Base = 'salat_base' -- base



SWEP.PrintName 				= "Šcorpion vz. 61"

SWEP.Author 				= "Česká zbrojovka Uherský Brod"

SWEP.Instructions			= "The Czechoslovak submachine gun was developed for arming tank crews, signalmen and military personnel of other specialties. The Scorpion was adopted by the Czechoslovak Republic in 1961."

SWEP.Category 				= "SIB SMG"



SWEP.Spawnable 				= true

SWEP.AdminOnly 				= false
if CLIENT then
	SWEP.WepSelectIcon = Material("pwb/sprites/vz61.vmt")
	SWEP.IconOverride = "pwb/sprites/vz61.vtf"
	SWEP.BounceWeaponIcon = false
end



------------------------------------------



SWEP.Primary.ClipSize		= 20

SWEP.Primary.DefaultClip	= 20

SWEP.Primary.Automatic		= true

SWEP.Primary.Ammo			= "7.65х17 mm"

SWEP.Primary.Cone = 0

SWEP.Primary.Damage = 27

SWEP.Primary.Spread = 0

SWEP.Primary.Sound = "weapons/tfa_ins2/vz61/vz61_fp.wav"

SWEP.Primary.FarSound = "snd_jack_hmcd_sht_far.wav"

SWEP.Primary.Force = 25

SWEP.ReloadTime = 1.9

SWEP.ShootWait = 0.055

SWEP.ReloadSounds = {

    [0.1] = {"weapons/mac10/clipout.wav"},

    [0.6] = {"weapons/mac10/clipin.wav"},

    [1.0] = {"weapons/mac10/boltforward.wav"},

    [1.2] = {"weapons/mac10/boltback.wav"},

}

SWEP.TwoHands = true

SWEP.ShellRotate = false



SWEP.Secondary.ClipSize		= -1

SWEP.Secondary.DefaultClip	= -1

SWEP.Secondary.Automatic	= false

SWEP.Secondary.Ammo			= "none"



------------------------------------------



SWEP.Weight					= 5

SWEP.AutoSwitchTo			= false

SWEP.AutoSwitchFrom			= false



SWEP.HoldType = "Revolver"



------------------------------------------



SWEP.Slot					= 2

SWEP.SlotPos				= 0

SWEP.DrawAmmo				= true

SWEP.DrawCrosshair			= false



SWEP.ViewModel				= "models/weapons/w_smg_skorp.mdl"

SWEP.WorldModel				= "models/weapons/w_smg_skorp.mdl"



SWEP.addAng = Angle(-2,1,0) -- Barrel pos adjust

SWEP.addPos = Vector(0,0,0) -- Barrel ang adjust

SWEP.SightPos = Vector(-14,0.8,2.34) -- Sight pos

SWEP.SightAng = Angle(-10,0,0) -- Sight ang

