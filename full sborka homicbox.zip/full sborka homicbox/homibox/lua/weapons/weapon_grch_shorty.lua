SWEP.Base = 'salat_base' -- base

SWEP.PrintName 				= "Serbu Super-Shorty"
SWEP.Author 				= "Serbu Firearms"
SWEP.Instructions			= "The Serbu Super-Shorty is a compact, stockless, pump action shotgun chambered in 12-gauge. The basic architecture of most of the production models is based on the Mossberg Maverick 88 shotgun, with Mossberg 500 and Remington 870 receivers also available."
SWEP.Category 				= "SIB Shotgun"

SWEP.Spawnable 				= true
SWEP.AdminOnly 				= false

------------------------------------------

SWEP.Primary.ClipSize		= 3
SWEP.Primary.DefaultClip	= 3
SWEP.Primary.Automatic		= false
SWEP.Primary.Ammo			= "12/70 gauge"
SWEP.Primary.Cone = 0.06
SWEP.Primary.Damage = 27
SWEP.Primary.Spread = 0
SWEP.Primary.Sound = "pwb/weapons/spas_12/shoot.wav"
SWEP.Primary.FarSound = "sounds_zcity/doublebarrel_short/dist.wav"
SWEP.Primary.Force = 100
SWEP.ReloadTime = 2.4
SWEP.ShootWait = 0.35
SWEP.NumBullet = 12
SWEP.ReloadSounds = {
    [0.2] = {"snd_jack_shotguninsert.wav"},
    [0.7] = {"snd_jack_shotguninsert.wav"},
    [1.2] = {"snd_jack_shotguninsert.wav"},
    [1.7] = {"snd_jack_hmcd_shotpump.wav"},
}
SWEP.TwoHands = true
SWEP.Shell = "EjectBrass_12Gauge"
SWEP.ShellRotate = false

SWEP.Secondary.ClipSize		= -1
SWEP.Secondary.DefaultClip	= -1
SWEP.Secondary.Automatic	= false
SWEP.Secondary.Ammo			= "none"

------------------------------------------

SWEP.Weight					= 5
SWEP.AutoSwitchTo			= false
SWEP.AutoSwitchFrom			= false

SWEP.HoldType = "smg"

------------------------------------------

SWEP.Slot					= 2
SWEP.SlotPos				= 0
SWEP.DrawAmmo				= true
SWEP.DrawCrosshair			= false

SWEP.ViewModel				= "models/weapons/w_shot_shortygun.mdl"
SWEP.WorldModel				= "models/weapons/w_shot_shortygun.mdl"

SWEP.addAng = Angle(0,0,0) -- Barrel pos adjust
SWEP.addPos = Vector(0,0,0) -- Barrel ang adjust
SWEP.SightPos = Vector(-5,0.6,3.3) -- Sight pos
SWEP.SightAng = Angle(-8,0,0) -- Sight ang


SWEP.Mobility = 1.5