SWEP.Base = 'salat_base' -- base

SWEP.PrintName              = "PКМ"
SWEP.Author                 = "Kalashnikov"
SWEP.Instructions           = "The soviet machine gun designed by M. T. Kalashnikov, V. V. Krupin, V. N. Pushkin, A. D. Kryakushin as a single machine gun for the Armed Forces of the USSR."
SWEP.Category               = "SIB Machine Gun"

SWEP.Spawnable              = true
SWEP.AdminOnly              = false
if CLIENT then
	SWEP.WepSelectIcon = Material("pwb2/vgui/weapons/pkm.vmt")
	SWEP.IconOverride = "pwb2/vgui/weapons/pkm.vtf"
	SWEP.BounceWeaponIcon = false
end

------------------------------------------

SWEP.Primary.ClipSize       = 100
SWEP.Primary.DefaultClip    = 100
SWEP.Primary.Automatic      = true
SWEP.Primary.Ammo           = "7.62x54 mm"
SWEP.Primary.Cone = 0
SWEP.Primary.Damage = 50
SWEP.Primary.Spread = 0
SWEP.Primary.Sound = "pwb2/weapons/pkm/pkm-1.wav"
SWEP.Primary.FarSound = "pwb/weapons/aks74u/shoot.wav"
SWEP.Primary.Force = 38
SWEP.ReloadTime = 5.0
SWEP.ShootWait = 0.10
SWEP.ReloadSounds = {
    [0.1] = {"pwb/weapons/pkm/coverup.wav"},
    [0.9] = {"pwb/weapons/pkm/boxout.wav"},
    [1.6] = {"pwb/weapons/pkm/draw.wav"},
    [2.0] = {"pwb/weapons/pkm/pkm_bullet.wav"},
    [2.3] = {"pwb/weapons/pkm/boxin.wav"},
    [3] = {"pwb/weapons/pkm/chain.wav"},
    [3.4] = {"pwb/weapons/pkm/coverdown.wav"},
    [4] = {"pwb/weapons/pkm/coversmack.wav"},
    [5] = {"pwb/weapons/pkm/bolt.wav"},
}
SWEP.TwoHands = true
SWEP.Shell = "EjectBrass_762Nato"

SWEP.Secondary.ClipSize     = -1
SWEP.Secondary.DefaultClip  = -1
SWEP.Secondary.Automatic    = false
SWEP.Secondary.Ammo         = "none"

------------------------------------------

SWEP.Weight                 = 5
SWEP.AutoSwitchTo           = false
SWEP.AutoSwitchFrom         = false

SWEP.HoldType = "ar2"

------------------------------------------

SWEP.Slot                   = 2
SWEP.SlotPos                = 0
SWEP.DrawAmmo               = true
SWEP.DrawCrosshair          = false

SWEP.ViewModel              = "models/pwb/weapons/w_pkm.mdl"
SWEP.WorldModel             = "models/pwb/weapons/w_pkm.mdl"

SWEP.addAng = Angle(-0.0,0.0,0) -- Barrel pos adjust
SWEP.addPos = Vector(0,0,0) -- Barrel ang adjust
SWEP.SightPos = Vector(-5,0.84,5.01) -- Sight pos
SWEP.SightAng = Angle(-7,-1,0) -- Sight ang

SWEP.Mobility = 3
--[[
local hg_skins = CreateClientConVar("hg_skins","1",true,false,"ubrat govno",0,1)

SWEP.PremiumSkin = {
    [0] = "skins/goldmat/goldmaterial", 
    [1] = "skins/goldmat/goldmaterial",
    [2] = "skins/goldmat/goldmaterial",
    [3] = "skins/goldmat/goldmaterial",
    [4] = "skins/goldmat/goldmaterial",
    [6] = "skins/goldmat/goldmaterial",
    [8] = "skins/goldmat/goldmaterial", 
}

function SWEP:DrawWorldModel()
    self:DrawModel()
    
    if not hg_skins:GetBool() then return end

    if (IsValid(self:GetOwner()) and self:GetOwner():IsPlayer() and skins[self:GetOwner():GetUserGroup()]) then
        for k,v in pairs(self.PremiumSkin) do
            self:SetSubMaterial( k, v )
        end
        self:DrawModel()
    end
end]]--