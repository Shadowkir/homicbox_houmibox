SWEP.Base = 'salat_base' -- base

SWEP.PrintName              = "АКМ"
SWEP.Author                 = "Kalashnikov"
SWEP.Instructions           = "The AKМ, officially known as the Avtomat Kalashnikova is a gas-operated assault rifle that is chambered for the 7.62×39mm cartridge."
SWEP.Category               = "SIB Rifles"

SWEP.Spawnable              = true
SWEP.AdminOnly              = false
if CLIENT then
	SWEP.WepSelectIcon = Material("vgui/akm.vmt")
	SWEP.IconOverride = "vgui/akm.vtf"
	SWEP.BounceWeaponIcon = false
end

------------------------------------------

SWEP.Primary.ClipSize       = 30
SWEP.Primary.DefaultClip    = 31
SWEP.Primary.Automatic      = true
SWEP.Primary.Ammo           = "7.62x39 mm"
SWEP.Primary.Cone = 0
SWEP.Primary.Damage = 50
SWEP.Primary.Spread = 0
SWEP.Primary.Sound = "kirs/akmfire1.ogg"
SWEP.Primary.FarSound = "weapons/ak47/distant.wav"
SWEP.Primary.Force = 30
SWEP.ReloadTime = 2.7
SWEP.ShootWait = 0.095
SWEP.ReloadSounds = {
    [0.3] = {"weapons/ak47/clipout.wav"},
    [1.3] = {"weapons/ak47/clipin.wav"},
    [1.8] = {"pwb/weapons/aks74u/boltpull.wav"},
}
SWEP.TwoHands = true
SWEP.Shell = "EjectBrass_762Nato"

SWEP.Secondary.ClipSize     = -1
SWEP.Secondary.DefaultClip  = -1
SWEP.Secondary.Automatic    = false
SWEP.Secondary.Ammo         = "none"

------------------------------------------

SWEP.Weight                 = 5
SWEP.AutoSwitchTo           = false
SWEP.AutoSwitchFrom         = false

SWEP.HoldType = "ar2"

------------------------------------------

SWEP.Slot                   = 2
SWEP.SlotPos                = 0
SWEP.DrawAmmo               = true
SWEP.DrawCrosshair          = false

SWEP.ViewModel              = "models/pwb/weapons/w_akm.mdl"
SWEP.WorldModel             = "models/pwb/weapons/w_akm.mdl"

SWEP.addAng = Angle(-0.0,0.0,0) -- Barrel pos adjust
SWEP.addPos = Vector(0,0,0) -- Barrel ang adjust
SWEP.SightPos = Vector(-5,0.75,5.01) -- Sight pos
SWEP.SightAng = Angle(-7,-1,0) -- Sight ang

SWEP.Mobility = 1
