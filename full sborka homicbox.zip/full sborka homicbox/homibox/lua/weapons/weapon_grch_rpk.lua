SWEP.Base = 'salat_base' -- base

SWEP.PrintName              = "RPK"
SWEP.Author                 = "Kalashnikov"
SWEP.Instructions           = "The Soviet light machine gun based on the AKM submachine gun. It was adopted by the Soviet army in 1961."
SWEP.Category               = "SIB Machine Gun"

SWEP.Spawnable              = true
SWEP.AdminOnly              = false
if CLIENT then
	SWEP.WepSelectIcon = Material("pwb/sprites/rpk.vmt")
	SWEP.IconOverride = "pwb/sprites/rpk.vtf"
	SWEP.BounceWeaponIcon = false
end

------------------------------------------

SWEP.Primary.ClipSize       = 95
SWEP.Primary.DefaultClip    = 95
SWEP.Primary.Automatic      = true
SWEP.Primary.Ammo           = "7.62x39 mm"
SWEP.Primary.Cone = 0
SWEP.Primary.Damage = 50
SWEP.Primary.Spread = 0
SWEP.Primary.Sound = "zcitysnd/sound/weapons/rpk/rpk_fp.wav"
SWEP.Primary.FarSound = "zcitysnd/sound/weapons/rpk/rpk_dist.wav"
SWEP.Primary.Force = 30
SWEP.ReloadTime = 5.2
SWEP.ShootWait = 0.095
SWEP.ReloadSounds = {
    [0.3] = {"pwb2/weapons/rpk/rpk_reload.wav"},

}
SWEP.TwoHands = true
SWEP.Shell = "EjectBrass_762Nato"

SWEP.Secondary.ClipSize     = -1
SWEP.Secondary.DefaultClip  = -1
SWEP.Secondary.Automatic    = false
SWEP.Secondary.Ammo         = "none"

------------------------------------------

SWEP.Weight                 = 8
SWEP.AutoSwitchTo           = false
SWEP.AutoSwitchFrom         = false

SWEP.HoldType = "ar2"

------------------------------------------

SWEP.Slot                   = 2
SWEP.SlotPos                = 0
SWEP.DrawAmmo               = true
SWEP.DrawCrosshair          = false

SWEP.ViewModel              = "models/pwb/weapons/w_rpk.mdl"
SWEP.WorldModel             = "models/pwb/weapons/w_rpk.mdl"

SWEP.addAng = Angle(0,0) -- Barrel pos adjust
SWEP.addPos = Vector(0,0,0) -- Barrel ang adjust
SWEP.SightPos = Vector(-5,0.835,4.61) -- Sight pos
SWEP.SightAng = Angle(-7,-1,0) -- Sight ang

SWEP.Mobility = 1
--[[
local hg_skins = CreateClientConVar("hg_skins","1",true,false,"ubrat govno",0,1)

SWEP.PremiumSkin = {
    [0] = "skins/goldmat/goldmaterial", 
    [1] = "skins/goldmat/goldmaterial",
    [2] = "skins/goldmat/goldmaterial",
    [3] = "skins/goldmat/goldmaterial",
    [4] = "skins/goldmat/goldmaterial",
    [6] = "skins/goldmat/goldmaterial",
    [8] = "skins/goldmat/goldmaterial", 
}

function SWEP:DrawWorldModel()
    self:DrawModel()
    
    if not hg_skins:GetBool() then return end

    if (IsValid(self:GetOwner()) and self:GetOwner():IsPlayer() and skins[self:GetOwner():GetUserGroup()]) then
        for k,v in pairs(self.PremiumSkin) do
            self:SetSubMaterial( k, v )
        end
        self:DrawModel()
    end
end]]--