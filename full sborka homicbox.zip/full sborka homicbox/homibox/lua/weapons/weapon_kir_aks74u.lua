SWEP.Base = 'salat_base' -- base

SWEP.PrintName 				= "АКS-74U"
SWEP.Author 				= "Kalashnikov"
SWEP.Instructions			= "A shortened version of the AKS-74 assault rifle was developed in the late 1970s and early 1980s to arm the crews of combat vehicles and aircraft of the USSR Armed Forces."
SWEP.Category 				= "SIB Rifles"

SWEP.Spawnable 				= true
SWEP.AdminOnly 				= false
SWEP.vbwPos = Vector(-2,9.5,7)
SWEP.vbwAng = Angle(10,-160,0)
if CLIENT then
	SWEP.WepSelectIcon = Material("pwb/sprites/aks74u.vmt")
	SWEP.IconOverride = "pwb/sprites/aks74u.vtf"
	SWEP.BounceWeaponIcon = false
end
------------------------------------------

SWEP.Primary.ClipSize		= 30
SWEP.Primary.DefaultClip	= 30
SWEP.Primary.Automatic		= true
SWEP.Primary.Ammo			= "5.45x39 mm"
SWEP.Primary.Cone = 0
SWEP.Primary.Damage = 42
SWEP.Primary.Spread = 0
SWEP.Primary.Sound = "pwb/weapons/aks74u/shoot.wav"
SWEP.Primary.FarSound = "sounds_zcity/ak74u/dist.wav"
SWEP.Primary.Force = 32
SWEP.ReloadTime = 2.8
SWEP.ShootWait = 0.095
SWEP.ReloadSounds = {
    [0.3] = {"pwb/weapons/aks74u/clipout.wav"},
    [1.3] = {"pwb/weapons/aks74u/clipin.wav"},
    [1.8] = {"pwb/weapons/aks74u/boltpull.wav"},
}
SWEP.TwoHands = true
SWEP.Shell = "EjectBrass_762Nato"

SWEP.Secondary.ClipSize		= -1
SWEP.Secondary.DefaultClip	= -1
SWEP.Secondary.Automatic	= false
SWEP.Secondary.Ammo			= "none"

------------------------------------------

SWEP.Weight					= 5
SWEP.AutoSwitchTo			= false
SWEP.AutoSwitchFrom			= false

SWEP.HoldType = "ar2"

------------------------------------------

SWEP.Slot					= 2
SWEP.SlotPos				= 0
SWEP.DrawAmmo				= true
SWEP.DrawCrosshair			= false

SWEP.ViewModel				= "models/pwb/weapons/w_aks74u.mdl"
SWEP.WorldModel				= "models/pwb/weapons/w_aks74u.mdl"

SWEP.addAng = Angle(0,-0.1,0) -- Barrel pos adjust
SWEP.addPos = Vector(0,0,0) -- Barrel ang adjust
SWEP.SightPos = Vector(-5,0.755,5.05) -- Sight pos
SWEP.SightAng = Angle(-8,0,0) -- Sight ang

SWEP.Mobility = 3





