SWEP.Base = 'salat_base' -- base



SWEP.PrintName 				= "M60"

SWEP.Author 				= "Saco Defense"

SWEP.Instructions			= "The American machine gun, developed in the post-war years and adopted by the Army and Marine Corps in 1957."

SWEP.Category 				= "SIB Machine Gun"



SWEP.Spawnable 				= true

SWEP.AdminOnly 				= false
if CLIENT then
	SWEP.WepSelectIcon = Material("pwb2/vgui/weapons/m60.vmt")
	SWEP.IconOverride = "pwb2/vgui/weapons/m60.vtf"
	SWEP.BounceWeaponIcon = false
end



------------------------------------------



SWEP.Primary.ClipSize		= 200

SWEP.Primary.DefaultClip	= 200

SWEP.Primary.Automatic		= true

SWEP.Primary.Ammo			= "7.62x51 NATO"

SWEP.Primary.Cone = 0

SWEP.Primary.Damage = 40

SWEP.Primary.Spread = 0

SWEP.Primary.Sound = "pwb2/weapons/m60/shoot.wav"

SWEP.Primary.FarSound = "weapons/ak47/distant.wav"

SWEP.Primary.Force = 35

SWEP.ReloadTime = 5

SWEP.ShootWait = 0.083000

SWEP.ReloadSounds = {
    [0.1] = {"pwb/weapons/pkm/coverup.wav"},
    [0.9] = {"pwb/weapons/pkm/boxout.wav"},
    [1.6] = {"pwb/weapons/pkm/draw.wav"},
    [2.3] = {"pwb/weapons/pkm/boxin.wav"},
    [3] = {"pwb/weapons/pkm/chain.wav"},
    [3.4] = {"pwb/weapons/pkm/coverdown.wav"},
    [4] = {"pwb/weapons/pkm/coversmack.wav"},
    [5] = {"pwb/weapons/pkm/bolt.wav"},
}

SWEP.TwoHands = true

SWEP.Shell = "EjectBrass_556"

SWEP.ShellRotate = false



SWEP.Secondary.ClipSize		= -1

SWEP.Secondary.DefaultClip	= -1

SWEP.Secondary.Automatic	= false

SWEP.Secondary.Ammo			= "none"



------------------------------------------



SWEP.Weight					= 5

SWEP.AutoSwitchTo			= false

SWEP.AutoSwitchFrom			= false



SWEP.HoldType = "ar2"



------------------------------------------



SWEP.Slot					= 2

SWEP.SlotPos				= 0

SWEP.DrawAmmo				= true

SWEP.DrawCrosshair			= false



SWEP.ViewModel				= "models/pwb2/weapons/w_m60.mdl"

SWEP.WorldModel				= "models/pwb2/weapons/w_m60.mdl"



SWEP.addAng = Angle(1,0,0) -- Barrel pos adjust

SWEP.addPos = Vector(0,0,0) -- Barrel ang adjust

SWEP.SightPos = Vector(-7,0.95,6.4) -- Sight pos

SWEP.SightAng = Angle(-2,0,0) -- Sight ang



SWEP.Mobility = 3

