SWEP.Base = 'salat_base' -- base

SWEP.PrintName 				= "Benelli M4 Auto"
SWEP.Author 				= "Benelli Armi SPA"
SWEP.Instructions			= "The Benelli M4 is a semi-automatic shotgun produced by Italian firearm manufacturer Benelli Armi SpA, and the fourth and last model of the Benelli Super 90 line of semi-automatic shotguns. The M4 uses a proprietary action design called the auto-regulating gas-operated (ARGO) system, which was created specifically for the weapon. Designed in 1998, the M4 was adopted by the armed forces of Italy, the United States, and United Kingdom, among others, and has been used in a variety of conflicts."
SWEP.Category 				= "SIB Shotgun"

SWEP.Spawnable 				= true
SWEP.AdminOnly 				= false

------------------------------------------

SWEP.Primary.ClipSize		= 8
SWEP.Primary.DefaultClip	= 8
SWEP.Primary.Automatic		= true
SWEP.Primary.Ammo			= "12/70 gauge"
SWEP.Primary.Cone = 0.025
SWEP.Primary.Damage = 26
SWEP.Primary.Spread = 0
SWEP.Primary.Sound = "weapons/mag7/fire01.wav"
SWEP.Primary.FarSound = "weapons/mag7/distant01.wav"
SWEP.Primary.Force = 60
SWEP.ReloadTime = 5
SWEP.ShootWait = 0.17
SWEP.NumBullet = 12
SWEP.ReloadSounds = {
    [0.3] = {"weapons/nova/insertshell01.wav"},
    [0.8] = {"weapons/nova/insertshell02.wav"},
    [1.3] = {"weapons/nova/insertshell03.wav"},
    [1.8] = {"weapons/nova/insertshell02.wav"},
    [2.3] = {"weapons/nova/insertshell01.wav"},
    [2.8] = {"weapons/nova/insertshell03.wav"},
    [3.3] = {"weapons/nova/insertshell02.wav"},
    [3.8] = {"weapons/nova/insertshell04.wav"},
    [4.3] = {"weapons/nova/pump.wav"},
}
SWEP.TwoHands = true
SWEP.Shell = "EjectBrass_12Gauge"

SWEP.Secondary.ClipSize		= -1
SWEP.Secondary.DefaultClip	= -1
SWEP.Secondary.Automatic	= false
SWEP.Secondary.Ammo			= "none"

------------------------------------------

SWEP.Weight					= 5
SWEP.AutoSwitchTo			= false
SWEP.AutoSwitchFrom			= false

SWEP.HoldType = "ar2"

------------------------------------------

SWEP.Slot					= 2
SWEP.SlotPos				= 0
SWEP.DrawAmmo				= true
SWEP.DrawCrosshair			= false

SWEP.ViewModel				= "models/homicbox_weapons/w_shot_xm1014.mdl"
SWEP.WorldModel				= "models/homicbox_weapons/w_shot_xm1014.mdl"

SWEP.addAng = Angle(0.5,0,0) -- Barrel pos adjust
SWEP.addPos = Vector(0,0,0) -- Barrel ang adjust
SWEP.SightPos = Vector(-9,0.8,3.1) -- Sight pos
SWEP.SightAng = Angle(-8,0,0) -- Sight ang


SWEP.Mobility = 1.5