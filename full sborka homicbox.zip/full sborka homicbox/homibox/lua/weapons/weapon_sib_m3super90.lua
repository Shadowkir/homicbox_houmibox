SWEP.Base = 'salat_base' -- base

SWEP.PrintName 				= "Benelli M3 Super 90"
SWEP.Author 				= "Benelli Armi SPA"
SWEP.Instructions			= "The Benelli M3 is a shotgun designed and manufactured by Italian firearms manufacturer Benelli Armi SpA, and the third model of the Benelli Super 90 line of semi-automatic shotguns."
SWEP.Category 				= "SIB Shotgun"

SWEP.Spawnable 				= true
SWEP.AdminOnly 				= false

------------------------------------------

SWEP.Primary.ClipSize		= 8
SWEP.Primary.DefaultClip	= 8
SWEP.Primary.Automatic		= false
SWEP.Primary.Ammo			= "12/70 gauge"
SWEP.Primary.Cone = 0.015
SWEP.Primary.Damage = 30
SWEP.Primary.Spread = 0
SWEP.Primary.Sound = "weapons/nova/fire.wav"
SWEP.Primary.FarSound = "weapons/nova/distant.wav"
SWEP.Primary.Force = 100
SWEP.ReloadTime = 5
SWEP.ShootWait = 0.3
SWEP.NumBullet = 12
SWEP.ReloadSounds = {
    [0.3] = {"weapons/nova/insertshell01.wav"},
    [0.8] = {"weapons/nova/insertshell02.wav"},
    [1.3] = {"weapons/nova/insertshell03.wav"},
    [1.8] = {"weapons/nova/insertshell02.wav"},
    [2.3] = {"weapons/nova/insertshell01.wav"},
    [2.8] = {"weapons/nova/insertshell03.wav"},
    [3.3] = {"weapons/nova/insertshell02.wav"},
    [3.8] = {"weapons/nova/insertshell04.wav"},
    [4.3] = {"weapons/nova/pump.wav"},
}
SWEP.TwoHands = true
SWEP.Shell = "EjectBrass_12Gauge"

SWEP.Secondary.ClipSize		= -1
SWEP.Secondary.DefaultClip	= -1
SWEP.Secondary.Automatic	= false
SWEP.Secondary.Ammo			= "none"

------------------------------------------

SWEP.Weight					= 5
SWEP.AutoSwitchTo			= false
SWEP.AutoSwitchFrom			= false

SWEP.HoldType = "ar2"

------------------------------------------

SWEP.Slot					= 2
SWEP.SlotPos				= 0
SWEP.DrawAmmo				= true
SWEP.DrawCrosshair			= false

SWEP.ViewModel				= "models/homicbox_weapons/w_shot_m3super90.mdl"
SWEP.WorldModel				= "models/homicbox_weapons/w_shot_m3super90.mdl"

SWEP.addAng = Angle(-0.5,0,0) -- Barrel pos adjust
SWEP.addPos = Vector(0,0,0) -- Barrel ang adjust
SWEP.SightPos = Vector(-5,0.97,3.6) -- Sight pos
SWEP.SightAng = Angle(-8,0,0) -- Sight ang


SWEP.Mobility = 1.5