SWEP.Base = 'salat_base' -- base



SWEP.PrintName 				= "FN F2000"

SWEP.Author 				= "FN Herstal"

SWEP.Instructions			= "The Belgian automatic rifle developed by FN Herstal using the bullpup system. FN F2000 was first introduced in 2001. These weapons are designed to perform combat missions in modern local military conflicts."

SWEP.Category 				= "SIB Rifles"



SWEP.Spawnable 				= true

SWEP.AdminOnly 				= false



------------------------------------------



SWEP.Primary.ClipSize		= 30

SWEP.Primary.DefaultClip	= 30

SWEP.Primary.Automatic		= true

SWEP.Primary.Ammo			= "5.56x45 mm"

SWEP.Primary.Cone = 0

SWEP.Primary.Damage = 32

SWEP.Primary.Spread = 0

SWEP.Primary.Sound = "sounds_zcity/hk21/close.wav"

SWEP.Primary.FarSound = "sounds_zcity/hk21/dist.wav"

SWEP.Primary.Force = 22

SWEP.ReloadTime = 2.5

SWEP.ShootWait = 0.065

SWEP.ReloadSounds = {

    [0.1] = {"weapons/m4a4/clipout.wav"},

    [1.3] = {"weapons/m4a4/clipin.wav"},

    [2] = {"weapons/m4a4/cliphit.wav"},

}

SWEP.TwoHands = true

SWEP.Shell = "EjectBrass_556"

SWEP.ShellRotate = true



SWEP.Secondary.ClipSize		= -1

SWEP.Secondary.DefaultClip	= -1

SWEP.Secondary.Automatic	= false

SWEP.Secondary.Ammo			= "none"



------------------------------------------



SWEP.Weight					= 5

SWEP.AutoSwitchTo			= false

SWEP.AutoSwitchFrom			= false



SWEP.HoldType = "ar2"



------------------------------------------



SWEP.Slot					= 2

SWEP.SlotPos				= 0

SWEP.DrawAmmo				= true

SWEP.DrawCrosshair			= false



SWEP.ViewModel				= "models/homicbox_weapons/w_rif_theia.mdl"

SWEP.WorldModel				= "models/homicbox_weapons/w_rif_theia.mdl"



SWEP.addAng = Angle(-2.4,2.0) -- Barrel pos adjust

SWEP.addPos = Vector(0,0,0) -- Barrel ang adjust

SWEP.SightPos = Vector(-9.5,1.14,4.3) -- Sight pos

SWEP.SightAng = Angle(-10,0,0) -- Sight ang



SWEP.Mobility = 1.3

