

SWEP.Base = 'salat_base' -- base



SWEP.PrintName 				= "MP 40"

SWEP.Author 				= "ERMA"

SWEP.Instructions			= "A submachine gun designed by Heinrich Vollmer based on the earlier ERMA EMP 36 and used as a personal weapon. He was in service with the Wehrmacht during World War II."

SWEP.Category 				= "SIB SMG"



SWEP.Spawnable 				= true

SWEP.AdminOnly 				= false



------------------------------------------



SWEP.Primary.ClipSize		= 32

SWEP.Primary.DefaultClip	= 32

SWEP.Primary.Automatic		= true

SWEP.Primary.Ammo			= "9х19 mm Parabellum"

SWEP.Primary.Cone = 0

SWEP.Primary.Damage = 35

SWEP.Primary.Spread = 0

SWEP.Primary.Sound = "zcitysnd/sound/weapons/mp40/mp40_fp.wav"

SWEP.Primary.FarSound = "zcitysnd/sound/weapons/mp40/mp40_dist.wav"

SWEP.Primary.Force = 25

SWEP.ReloadTime = 2.6

SWEP.ShootWait = 0.11

SWEP.ReloadSounds = {

    [0.1] = {"weapons/ump45/clipout.wav"},

    [0.9] = {"weapons/ump45/clipin.wav"},

    [1.5] = {"weapons/tfa_ins2/ak103/ak103_boltback.wav"},

    [1.9] = {"weapons/tfa_ins2/ak103/ak103_boltrelease.wav"},
}

SWEP.TwoHands = true

SWEP.ShellRotate = false



SWEP.Secondary.ClipSize		= -1

SWEP.Secondary.DefaultClip	= -1

SWEP.Secondary.Automatic	= false

SWEP.Secondary.Ammo			= "none"



------------------------------------------



SWEP.Weight					= 5

SWEP.AutoSwitchTo			= false

SWEP.AutoSwitchFrom			= false



SWEP.HoldType = "smg"



------------------------------------------



SWEP.Slot					= 2

SWEP.SlotPos				= 0

SWEP.DrawAmmo				= true

SWEP.DrawCrosshair			= false



SWEP.ViewModel				= "models/weapons/w_smg_mp4.mdl"

SWEP.WorldModel				= "models/weapons/w_smg_mp4.mdl"



SWEP.addAng = Angle(-1,-1,0) -- Barrel pos adjust

SWEP.addPos = Vector(0,0,0) -- Barrel ang adjust

SWEP.SightPos = Vector(-8,0.44,3.9) -- Sight pos

SWEP.SightAng = Angle(-10,0,0) -- Sight ang



SWEP.Mobility = 1.3

