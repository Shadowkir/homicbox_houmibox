ENT.Type = "anim"
ENT.Base = "base_gmodentity"

ENT.PrintName = "homibox loot base"
ENT.Category = "Looting"

ENT.Spawnable = true

ENT.Model = "models/kali/props/cases/hard case c.mdl"
ENT.ModelMaterial = "models/jmod_block/metal"

ENT.LootTable = {
}

ENT.RandomLoot = {
    [1] = {
    }
}

ENT.UpdateTime = CurTime()