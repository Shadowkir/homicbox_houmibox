AddCSLuaFile()

ENT.Base = "ent_hb_emp_base"

ENT.PrintName = "PKM"
ENT.Category = "Стационарное Оружие"

ENT.Spawnable = true
ENT.BaseModel = "models/hunter/blocks/cube025x025x025.mdl" 

ENT.GunModel = "models/pwb/weapons/w_pkm.mdl"
ENT.NextShoot = 0

ENT.Damage = 50
ENT.Force = 50

ENT.MaxClip = 100
ENT.Clip = 100
ENT.Delay = 0.1

ENT.ReloadSounds = {
    [0.1] = {"pwb/weapons/pkm/coverup.wav"},
    [0.9] = {"pwb/weapons/pkm/boxout.wav"},
    [1.6] = {"pwb/weapons/pkm/draw.wav"},
    [2.0] = {"pwb/weapons/pkm/pkm_bullet.wav"},
    [2.3] = {"pwb/weapons/pkm/boxin.wav"},
    [3] = {"pwb/weapons/pkm/chain.wav"},
    [3.4] = {"pwb/weapons/pkm/coverdown.wav"},
    [4] = {"pwb/weapons/pkm/coversmack.wav"},
    [5] = {"pwb/weapons/pkm/bolt.wav"},
}

ENT.ShootSound = "pwb/weapons/pkm/shoot.wav"
ENT.ShootSoundFar = "snd_jack_hmcd_snp_far.wav"
