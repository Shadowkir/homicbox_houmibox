SWEP.Base = "weapon_hg_granade_base"

SWEP.PrintName = "Светошумовая Граната"
--
SWEP.Instructions = "Специальное средство несмертельного действия, оказывающие на человека светозвуковое и осколочное воздействие."
SWEP.Category = "Гранаты"

SWEP.Slot = 4
SWEP.SlotPos = 2
SWEP.Spawnable = true

SWEP.ViewModel = "models/jmod/explosives/grenades/flashbang/flashbang.mdl"
SWEP.WorldModel = "models/jmod/explosives/grenades/flashbang/flashbang.mdl"

SWEP.Granade = "ent_hgjack_flashbang"

function SWEP:DrawWorldModel()
    local owner = self:GetOwner()
    if not IsValid(owner) then self:DrawModel() return end

    local mdl = self.worldModel
    if not IsValid(mdl) then
        mdl = ClientsideModel(self.WorldModel)
        mdl:SetNoDraw(true)
        mdl:SetModelScale(0.8)

        self.worldModel = mdl
    end
    self:CallOnRemove("huyhuy",function() mdl:Remove() end)

    local matrix = self:GetOwner():GetBoneMatrix(11)
    if not matrix then return end

    mdl:SetRenderOrigin(matrix:GetTranslation()+matrix:GetAngles():Forward()*3+matrix:GetAngles():Right()*2)
    mdl:SetRenderAngles(matrix:GetAngles())
    mdl:DrawModel()
end

local zeroang = Angle(0,0,0)

local clavicler = Angle(30, 0, 60)

function SWEP:Initialize()
    self:SetHoldType("slam")
end

function SWEP:Deploy()
    self:SetHoldType("slam")
end

function SWEP:Holster()
	local ply = self:GetOwner()
	timer.Simple(0.1,function()
    ply:ManipulateBoneAngles(ply:LookupBone("ValveBiped.Bip01_R_Clavicle"), zeroang, true)
    ply:ManipulateBoneAngles(ply:LookupBone("ValveBiped.Bip01_R_Finger0"),zeroang,true)
	end)
	return true
end

function SWEP:Think()
    self.Anim = Lerp(.1, self.Anim or 0, 1)
    local ply = self:GetOwner()
    self:GetOwner():ManipulateBoneAngles(self:GetOwner():LookupBone("ValveBiped.Bip01_R_Clavicle"), clavicler * self.Anim, true)
    ply:ManipulateBoneAngles(ply:LookupBone("ValveBiped.Bip01_R_Finger0"),Angle(10,30,0) * self.Anim,true)
end