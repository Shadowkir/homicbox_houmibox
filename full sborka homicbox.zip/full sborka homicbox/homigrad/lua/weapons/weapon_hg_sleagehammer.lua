SWEP.Base = "weapon_hg_melee_base"

SWEP.PrintName = "Кувалда"
SWEP.Category = "Ближний Бой"
SWEP.Instructions = "Ручной ударный инструмент, предназначенный для боя камня, нанесения исключительно сильных ударов при обработке металла, на демонтаже и монтаже конструкций."
SWEP.Spawnable= true
SWEP.AdminSpawnable= true
SWEP.AdminOnly = false

SWEP.ViewModelFOV = 60
SWEP.ViewModel = "models/weapons/me_sledge/w_me_sledge.mdl"
SWEP.WorldModel = "models/weapons/me_sledge/w_me_sledge.mdl"
SWEP.ViewModelFlip = false

SWEP.AutoSwitchTo = false
SWEP.AutoSwitchFrom = false

SWEP.Slot = 1
SWEP.SlotPos = 2

SWEP.UseHands = true

---SWEP.HoldType = "knife"

SWEP.FiresUnderwater = false

SWEP.DrawCrosshair = false

SWEP.DrawAmmo = true

SWEP.Primary.Damage = 55
SWEP.Primary.Ammo = "none"
SWEP.Primary.DefaultClip = -1
SWEP.Primary.Automatic = true
SWEP.Primary.Recoil = 0.5
SWEP.Primary.Delay = 1.4
SWEP.Primary.Force = 150

SWEP.Secondary.ClipSize = 0
SWEP.Secondary.DefaultClip = 0
SWEP.Secondary.Automatic = false
SWEP.Secondary.Ammo = "none"

SWEP.DrawSound = "weapons/melee/holster_in_light.wav"
SWEP.HitSound = "physics/metal/metal_sheet_impact_hard2.wav"
SWEP.FlashHitSound = "weapons/melee/flesh_impact_blunt_04.wav"
SWEP.ShouldDecal = false
SWEP.HoldTypeWep = "melee2"
SWEP.DamageType = DMG_CLUB

local function IsDoor(ent)
    return IsValid(ent) and string.find(ent:GetClass():lower(), "door")
end

hook.Add("EntityTakeDamage", "SledgehammerBreakDoor", function(ent, dmg)
    local wep = dmg:GetInflictor()
    if not IsValid(wep) or wep:GetClass() ~= "weapon_hg_sleagehammer" then return end
    if not IsDoor(ent) then return end

    dmg:SetDamage(0) -- не наносим урон, чтобы не сломать базовую логику

    ent:Fire("Unlock")

    -- превращаем в prop_physics
    local prop = ents.Create("prop_physics")
    if not IsValid(prop) then return end

    prop:SetModel(ent:GetModel())
    prop:SetPos(ent:GetPos())
    prop:SetAngles(ent:GetAngles())
    prop:SetSkin(ent:GetSkin() or 0)
    prop:SetMaterial(ent:GetMaterial() or "")
    prop:Activate()

    local phys = prop:GetPhysicsObject()
    if IsValid(phys) then
        phys:EnableMotion(true)
        phys:Wake()
        local owner = dmg:GetAttacker()
        local dir = IsValid(owner) and owner:GetAimVector() or dmg:GetDamageForce():GetNormalized()
        phys:SetVelocity(dir * 800 + Vector(0, 0, 300))
    end

    ent:Remove()

    -- звук
    prop:EmitSound("physics/wood/wood_crate_break" .. math.random(1, 5) .. ".wav")
end)