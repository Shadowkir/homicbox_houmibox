SWEP.Base = "weapon_hg_granade_base"

SWEP.PrintName = "F1"
--
SWEP.Instructions = "Ручная граната дистанционного действия, предназначена для поражения живой силы противника в оборонительном бою."
SWEP.Category = "Гранаты"

SWEP.Slot = 4
SWEP.SlotPos = 2
SWEP.Spawnable = true

SWEP.ViewModel = "models/pwb/weapons/w_f1.mdl"
SWEP.WorldModel = "models/pwb/weapons/w_f1.mdl"

SWEP.Granade = "ent_hgjack_f1nade"